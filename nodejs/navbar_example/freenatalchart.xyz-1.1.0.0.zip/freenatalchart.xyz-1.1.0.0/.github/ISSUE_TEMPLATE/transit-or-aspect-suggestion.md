---
name: Transit or Aspect Suggestion
about: Ideas/issues with how aspects and transits are presented
title: Transit or Aspect Suggestion
labels: transits
assignees: ''

---

Are aspects or transits in your chart missing, or presented in a way that looks wrong? Do you have comments about how we choose which aspects we draw or show, or maybe about how aspects are selected as "active", or in what order they're presented? Let us know!
